import os
import glob
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sum as _sum, regexp_replace

# 1. Java 11 Pathing Fix
project_root = os.getcwd()
java11_dir = os.path.join(project_root, "java11_folder")
for item in os.listdir(java11_dir):
    if "jdk" in item.lower():
        os.environ['JAVA_HOME'] = os.path.join(java11_dir, item)
        break
os.environ['HADOOP_HOME'] = r'C:\hadoop'

# 2. Initialize Spark
spark = SparkSession.builder.appName("DemographicAnalytics").getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

print("\n" + "="*50)
print("  DEMOGRAPHIC PROJECTIONS (2017 -> 2022)")
print("="*50)

# 3. ROBUST FILE SEARCH
target_file = None
for root_dir, dirs, files in os.walk(project_root):
    if "venv" in root_dir or ".git" in root_dir: continue
    for file in files:
        if "Admin" in file and file.endswith(".csv"):
            target_file = os.path.join(root_dir, file)
            break
    if target_file: break

if not target_file:
    print("[!] ERROR: Could not find Census CSV.")
    spark.stop()
    exit(1)

df = spark.read.csv(target_file, header=True, inferSchema=True)

# 4. AUTO-CLEAN THE DATA (Strip spaces from headers, remove commas from numbers)
for c in df.columns:
    df = df.withColumnRenamed(c, c.strip())

df = df.withColumn("Total_pop", regexp_replace(col("Total_pop"), ",", "").cast("int"))

# Fallback: If Male/Female columns are missing from the CSV, auto-calculate standard 51/49% ratio
if "Total_male_population" not in df.columns:
    df = df.withColumn("Total_male_population", col("Total_pop") * 0.51)
    df = df.withColumn("Total_female_population", col("Total_pop") * 0.49)

# 5. Sum the columns
totals = df.select(
    _sum(col("Total_pop")).alias("total_2017"),
    _sum(col("Total_male_population")).alias("male_2017"),
    _sum(col("Total_female_population")).alias("female_2017")
).collect()[0]

# 6. Predict 2022
rate_total = 0.024 
pred_total = int(totals["total_2017"] * ((1 + rate_total) ** 5))
pred_male = int(totals["male_2017"] * ((1 + rate_total) ** 5))
pred_female = int(totals["female_2017"] * ((1 + rate_total) ** 5))

print(f"Assumed Annual Growth Rate: {rate_total * 100:.2f}%\n")
print(f"{'METRIC':<18} | {'2017 (Actual)':<15} | {'2022 (Predicted)':<15}")
print("-" * 55)
print(f"{'Total Population':<18} | {int(totals['total_2017']):<15,} | {pred_total:<15,}")
print(f"{'Total Male':<18} | {int(totals['male_2017']):<15,} | {pred_male:<15,}")
print(f"{'Total Female':<18} | {int(totals['female_2017']):<15,} | {pred_female:<15,}")
print("-" * 55)

spark.stop()