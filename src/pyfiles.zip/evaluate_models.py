import os
from pyspark.sql import SparkSession
from pyspark.ml.evaluation import MulticlassClassificationEvaluator, ClusteringEvaluator
from pyspark.ml.classification import RandomForestClassificationModel
from pyspark.ml.clustering import KMeansModel
from pyspark.ml.feature import VectorAssembler

# 1. Pathing Fixes
project_root = os.getcwd()
java11_dir = os.path.join(project_root, "java11_folder")
for item in os.listdir(java11_dir):
    if "jdk" in item.lower():
        os.environ['JAVA_HOME'] = os.path.join(java11_dir, item)
        break
os.environ['HADOOP_HOME'] = r'C:\hadoop'

# 2. Initialize Spark
spark = SparkSession.builder.appName("ModelEvaluation").getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

print("\n" + "="*50)
print("  MACHINE LEARNING REPORT CARD  ")
print("="*50)

# ---------------------------------------------------------
# TEST 1: RANDOM FOREST (SPRAWL PREDICTOR)
# ---------------------------------------------------------
print("[+] Testing Random Forest Accuracy...")
data_path = os.path.join(project_root, "data", "processed", "ml_features.parquet")
rf_model_path = os.path.join(project_root, "models", "rf_model")

# Load historical data and model
df = spark.read.parquet(data_path)
rf_model = RandomForestClassificationModel.load(rf_model_path)

# Ensure features are assembled for testing
assembler = VectorAssembler(inputCols=["lat", "lon", "density_score"], outputCol="features")
df_test = assembler.transform(df)

# Generate Predictions on historical data
rf_predictions = rf_model.transform(df_test)

# Calculate Metrics
evaluator = MulticlassClassificationEvaluator(labelCol="is_urban", predictionCol="prediction")

accuracy = evaluator.evaluate(rf_predictions, {evaluator.metricName: "accuracy"})
f1_score = evaluator.evaluate(rf_predictions, {evaluator.metricName: "f1"})

print("\n--- RANDOM FOREST SCORES ---")
print(f"Overall Accuracy : {accuracy * 100:.2f}%")
print(f"F1-Score         : {f1_score * 100:.2f}% (Balance of Precision & Recall)")

if accuracy > 0.85:
    print("Status: EXCELLENT (Highly reliable sprawl prediction)")
elif accuracy > 0.70:
    print("Status: GOOD (Solid baseline, but some noise)")
else:
    print("Status: NEEDS TUNING (Model is confused)")

# ---------------------------------------------------------
# TEST 2: K-MEANS (FUTURE EPICENTERS)
# ---------------------------------------------------------
print("\n[+] Testing K-Means Clustering Quality...")
sprawl_data_path = os.path.join(project_root, "data", "predictions", "sprawl_2030.parquet")
sprawl_df = spark.read.parquet(sprawl_data_path)

# Assemble coordinates for cluster evaluation
kmeans_assembler = VectorAssembler(inputCols=["lat", "lon"], outputCol="features")
sprawl_features = kmeans_assembler.transform(sprawl_df)

# We must quickly re-run K-Means to evaluate the clusters in memory
from pyspark.ml.clustering import KMeans
kmeans = KMeans().setK(15).setSeed(42).setFeaturesCol("features")
kmeans_model = kmeans.fit(sprawl_features)
cluster_predictions = kmeans_model.transform(sprawl_features)

# Calculate Silhouette Score
silhouette_evaluator = ClusteringEvaluator(featuresCol="features", predictionCol="prediction")
silhouette = silhouette_evaluator.evaluate(cluster_predictions)

print("\n--- K-MEANS CLUSTERING SCORES ---")
print(f"Silhouette Score : {silhouette:.4f} (Range: -1.0 to 1.0)")

if silhouette > 0.5:
    print("Status: STRONG (Epicenters are highly distinct and realistic)")
elif silhouette > 0.25:
    print("Status: MODERATE (Cities are starting to merge together)")
else:
    print("Status: WEAK (Sprawl is too scattered to form clear centers)")

print("\n" + "="*50)
spark.stop()