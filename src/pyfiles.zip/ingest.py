import os
import glob
from pyspark.sql import SparkSession

# 1. Java 11 & Hadoop Fix
project_root = os.getcwd()
java11_dir = os.path.join(project_root, "java11_folder")
for item in os.listdir(java11_dir):
    if "jdk" in item.lower():
        os.environ['JAVA_HOME'] = os.path.join(java11_dir, item)
        break
os.environ['HADOOP_HOME'] = r'C:\hadoop'

# 2. Initialize Spark
spark = SparkSession.builder.appName("DataIngestion").getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

print("\n" + "="*30)
print("  TASK 2: DATA INGESTION")
print("="*30)

# 3. Ingest Census Data (CSV)
census_path = os.path.join(project_root, "data", "raw", "census", "*.csv")
census_files = glob.glob(census_path)

if census_files:
    print(f"[+] Loading Census: {os.path.basename(census_files[0])}")
    df_census = spark.read.csv(census_files[0], header=True, inferSchema=True)
    print(f"    Row Count: {df_census.count()}")
    df_census.printSchema()
    df_census.show(5)
else:
    print("[-] ERROR: No CSV found in data/raw/census/")

# 4. Check WorldPop Data (TIF)
# (Note: We will process the pixels into a Spark DF in Task 3)
wp_path = os.path.join(project_root, "data", "raw", "worldpop", "*.tif")
wp_files = glob.glob(wp_path)

if wp_files:
    print(f"[+] WorldPop File Detected: {os.path.basename(wp_files[0])}")
    print("    Ready for pixel-to-coordinate transformation in Task 3.")
else:
    print("[-] ERROR: No TIF found in data/raw/worldpop/")

print("\nIngestion Script Finished Successfully.")
spark.stop()
