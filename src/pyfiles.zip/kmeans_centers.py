import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.clustering import KMeans
import pandas as pd

# 1. Java 11 & Hadoop Dynamic Pathing Fix
project_root = os.getcwd()
java11_dir = os.path.join(project_root, "java11_folder")
for item in os.listdir(java11_dir):
    if "jdk" in item.lower():
        os.environ['JAVA_HOME'] = os.path.join(java11_dir, item)
        break
os.environ['HADOOP_HOME'] = r'C:\hadoop'

# 2. Initialize Spark
spark = SparkSession.builder \
    .appName("FutureCityCenters") \
    .getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

print("\n" + "="*55)
print("  FEATURE 1: K-MEANS FUTURE CITY CENTERS (2030)")
print("="*55)

# 3. Load the 5,000 Sprawl Points we generated in Task 6
data_path = os.path.join(project_root, "data", "predictions", "sprawl_2030.parquet")
print(f"[+] Loading predicted sprawl data from: {os.path.basename(data_path)}")
df = spark.read.parquet(data_path)

# 4. Assemble Coordinates for ML
print("[+] Assembling geographic coordinates...")
assembler = VectorAssembler(inputCols=["lat", "lon"], outputCol="features")
df_features = assembler.transform(df)

# 5. Train K-Means Algorithm
num_clusters = 15 # We are telling the AI to find the top 15 mega-centers
print(f"[+] Running K-Means AI to find {num_clusters} future city epicenters...")
kmeans = KMeans().setK(num_clusters).setSeed(42).setFeaturesCol("features")
model = kmeans.fit(df_features)

# 6. Extract the Coordinates of the New Centers
centers = model.clusterCenters()

print("\n--- TOP PREDICTED FUTURE CITY CENTERS (LAT, LON) ---")
centers_data = []
for i, center in enumerate(centers):
    lat = round(center[0], 4)
    lon = round(center[1], 4)
    print(f"City Center {i+1:<2}: Latitude {lat:<8}, Longitude {lon}")
    centers_data.append({"center_id": i+1, "lat": lat, "lon": lon})

# 7. Save Centers to a CSV for mapping
centers_df = pd.DataFrame(centers_data)
out_path = os.path.join(project_root, "data", "predictions", "future_city_centers.csv")
centers_df.to_csv(out_path, index=False)

print(f"\n[+] Saved epicenters to: {out_path}")
print("Task Completed Successfully!")

spark.stop()