import os
import pandas as pd
import folium
from branca.element import Template, MacroElement
from pyspark.sql import SparkSession

# 1. Pathing Fixes
project_root = os.getcwd()
java11_dir = os.path.join(project_root, "java11_folder")
for item in os.listdir(java11_dir):
    if "jdk" in item.lower():
        os.environ['JAVA_HOME'] = os.path.join(java11_dir, item)
        break
os.environ['HADOOP_HOME'] = r'C:\hadoop'

# 2. Initialize Spark
spark = SparkSession.builder.appName("SatelliteVisualization").getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

# 3. Load All 3 Datasets
sprawl_path = os.path.join(project_root, "data", "predictions", "sprawl_2030.parquet")
peri_urban_path = os.path.join(project_root, "data", "predictions", "peri_urban_2030.parquet")
centers_path = os.path.join(project_root, "data", "predictions", "future_city_centers.csv")

df_sprawl = spark.read.parquet(sprawl_path).toPandas()
df_suburbs = spark.read.parquet(peri_urban_path).toPandas()
df_centers = pd.read_csv(centers_path)

# 4. Create the Base Map
print("[+] Rendering the map layers...")
pakistan_map = folium.Map(location=[30.3753, 69.3451], zoom_start=6)

# --- ADDING THE 3 MAP LAYERS ---
# Layer A: Dark Mode (Default)
folium.TileLayer('CartoDB dark_matter', name="Dark Dashboard").add_to(pakistan_map)

# Layer B: Street View (To see city names)
folium.TileLayer('OpenStreetMap', name="Street Labels", show=False).add_to(pakistan_map)

# Layer C: Real Satellite View (To see the actual terrain)
folium.TileLayer(
    tiles='https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attr='Esri',
    name='Satellite X-Ray',
    show=False
).add_to(pakistan_map)
# -------------------------------

# 5. Add Layer 1: Peri-Urban Suburbs 
for idx, row in df_suburbs.iterrows():
    folium.CircleMarker(
        location=[row['lat'], row['lon']], radius=3.5, color='#FF8C00', weight=0, fill=True, fill_color='#FF8C00', fill_opacity=0.35
    ).add_to(pakistan_map)

# 6. Add Layer 2: The Hardcore Sprawl 
for idx, row in df_sprawl.iterrows():
    folium.CircleMarker(
        location=[row['lat'], row['lon']], radius=1.5, color='#ff0044', weight=0, fill=True, fill_color='#ff0044', fill_opacity=0.8
    ).add_to(pakistan_map)

# 7. Add Layer 3: The 15 Future Epicenters 
for idx, row in df_centers.iterrows():
    folium.CircleMarker(
        location=[row['lat'], row['lon']], radius=14, color='#FFD700', weight=1.5, fill=True, fill_color='#FFD700', fill_opacity=0.4,
        tooltip=f"<b>Future Mega-Center #{row['center_id']}</b>"
    ).add_to(pakistan_map)
    folium.Marker(
        location=[row['lat'], row['lon']], icon=folium.Icon(color='orange', icon='star')
    ).add_to(pakistan_map)

# 8. Add Map Controls (This creates the button to switch to Satellite)
folium.LayerControl(position='topright').add_to(pakistan_map)

# 9. Save
output_map_path = os.path.join(project_root, "beautiful_sprawl_map.html")
pakistan_map.save(output_map_path)
print(f"\n[+] Masterpiece saved! Open {output_map_path}")
spark.stop()