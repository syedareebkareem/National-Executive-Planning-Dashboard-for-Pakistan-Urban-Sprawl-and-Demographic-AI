import os
from pyspark.sql import SparkSession
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.evaluation import MulticlassClassificationEvaluator

# 1. Java 11 & Hadoop Dynamic Pathing Fix (Kept for VS Code terminal safety)
project_root = os.getcwd()
java11_dir = os.path.join(project_root, "java11_folder")
for item in os.listdir(java11_dir):
    if "jdk" in item.lower():
        os.environ['JAVA_HOME'] = os.path.join(java11_dir, item)
        break
os.environ['HADOOP_HOME'] = r'C:\hadoop'

# 2. Initialize Spark Session
spark = SparkSession.builder \
    .appName("SprawlPredictionModel") \
    .config("spark.driver.memory", "4g") \
    .getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

print("\n" + "="*40)
print("  TASK 5: MACHINE LEARNING (RANDOM FOREST)")
print("="*40)

# 3. Load ML-Ready Data
input_path = os.path.join(project_root, "data", "processed", "ml_features.parquet")
print(f"[+] Loading dataset from {os.path.basename(input_path)}...")
df = spark.read.parquet(input_path)

# 4. Prepare Features for Spark MLlib
print("[+] Assembling ML Features (lat, lon, density_score)...")
# Spark requires all input features to be bundled into a single array column called "features"
assembler = VectorAssembler(
    inputCols=["lat", "lon", "density_score"], 
    outputCol="features"
)
df_ml = assembler.transform(df).select("grid_id", "features", "is_urban")

# 5. Train / Test Split
print("[+] Splitting Data (80% Training, 20% Testing)...")
train_data, test_data = df_ml.randomSplit([0.8, 0.2], seed=42)

print(f"    Training Rows: {train_data.count():,}")
print(f"    Testing Rows:  {test_data.count():,}")

# 6. Train the Random Forest Model
print("\n[+] Training Random Forest Classifier (This may take a minute)...")
rf = RandomForestClassifier(labelCol="is_urban", featuresCol="features", numTrees=20, maxDepth=5)
model = rf.fit(train_data)
print("[+] Model Training Complete!")

# 7. Evaluate the Model
print("\n[+] Evaluating Model on Test Data...")
predictions = model.transform(test_data)

evaluator = MulticlassClassificationEvaluator(labelCol="is_urban", predictionCol="prediction", metricName="accuracy")
accuracy = evaluator.evaluate(predictions)

print("\n--- MODEL PERFORMANCE ---")
print(f"Accuracy: {accuracy * 100:.2f}%")

# 8. Save the Model
model_path = os.path.join(project_root, "models", "rf_model")
print(f"\n[+] Saving trained model to: {model_path}")
model.write().overwrite().save(model_path)

print("\nTask 5 Completed Successfully!")
spark.stop()