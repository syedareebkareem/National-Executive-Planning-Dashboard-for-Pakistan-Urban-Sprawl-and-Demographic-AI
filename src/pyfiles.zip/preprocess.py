import os
import glob
import rasterio
import numpy as np
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, round

# 1. Java 11 & Hadoop Dynamic Pathing Fix
project_root = os.getcwd()
java11_dir = os.path.join(project_root, "java11_folder")
for item in os.listdir(java11_dir):
    if "jdk" in item.lower():
        os.environ['JAVA_HOME'] = os.path.join(java11_dir, item)
        break
os.environ['HADOOP_HOME'] = r'C:\hadoop'

# 2. Initialize Spark with extra memory
spark = SparkSession.builder \
    .appName("DataCleaning") \
    .config("spark.driver.memory", "4g") \
    .getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

print("\n" + "="*35)
print("  TASK 3: SPATIAL DATA CLEANING")
print("="*35)

# 3. Process the WorldPop TIF file
wp_path = glob.glob(os.path.join(project_root, "data", "raw", "worldpop", "*.tif"))
if not wp_path:
    raise FileNotFoundError("WorldPop TIF file not found in data/raw/worldpop/")

print(f"[+] Loading Raster: {os.path.basename(wp_path[0])}")

with rasterio.open(wp_path[0]) as src:
    data = src.read(1)
    
    # Filter out empty pixels (population < 0.1) to save RAM
    mask = data > 0.1 
    rows, cols = np.where(mask)
    
    print("[+] Extracting spatial coordinates...")
    xs, ys = rasterio.transform.xy(src.transform, rows, cols)
    pops = data[rows, cols]

print(f"[+] Extracted {len(pops)} populated grid cells.")

# Limit to 3 million points to prevent local laptop memory crash
if len(pops) > 3000000:
    print("[!] Downsampling to 3 million points for local processing...")
    sample_indices = np.random.choice(len(pops), 3000000, replace=False)
    xs = np.array(xs)[sample_indices]
    ys = np.array(ys)[sample_indices]
    pops = pops[sample_indices]

# 4. Push to Spark
print("[+] Converting to Distributed Spark DataFrame...")
pdf = pd.DataFrame({"lon": xs, "lat": ys, "population": pops})
df = spark.createDataFrame(pdf)

# 5. Clean and Transform in PySpark (Per Blueprint)
print("[+] Applying PySpark Transformations...")
df_clean = df.filter(
    (col("lat") >= 23.0) & (col("lat") <= 37.0) &  # Pakistan Latitude Bounds
    (col("lon") >= 60.0) & (col("lon") <= 77.0)    # Pakistan Longitude Bounds
).dropna()

# Cast types and add columns
df_clean = df_clean.withColumn("lat", round(col("lat"), 5)) \
                   .withColumn("lon", round(col("lon"), 5)) \
                   .withColumn("population", col("population").cast("double")) \
                   .withColumn("year", lit(2020))

print(f"[+] Final Cleaned Row Count: {df_clean.count()}")
df_clean.show(5)

# 6. Save to Parquet
out_dir = os.path.join(project_root, "data", "processed", "cleaned.parquet")
print(f"[+] Saving optimized Big Data Parquet file to: {out_dir}")
df_clean.write.mode("overwrite").parquet(out_dir)

print("\nTask 3 Completed Successfully!")
spark.stop()
