import streamlit as st
import pandas as pd
import folium
from streamlit_folium import st_folium
import plotly.express as px
import os

# Page Config
st.set_page_config(page_title="Pakistan Urban Sprawl AI", layout="wide")

st.title("🇵🇰 Pakistan Urban Sprawl & Demographic AI")
st.markdown("### National Executive Planning Dashboard (1998 - 2030)")

# --- SIDEBAR CONTROLS ---
st.sidebar.header("Control Panel")
year = st.sidebar.select_slider("Select Prediction Year", options=[1998, 2017, 2022, 2030], value=2030)

# --- DATA LOADING LOGIC ---
# (Simulated aggregates based on your previous task results)
stats = {
    1998: {"pop": 130.7, "urban": "32%", "color": "#32CD32"},
    2017: {"pop": 204.4, "urban": "36%", "color": "#1E90FF"},
    2022: {"pop": 230.1, "urban": "39%", "color": "#FFA500"},
    2030: {"pop": 280.5, "urban": "45%", "color": "#FF0044"}
}

# --- TOP METRICS ---
col1, col2, col3 = st.columns(3)
col1.metric("Projected Population", f"{stats[year]['pop']} Million")
col2.metric("Urbanization Rate", stats[year]['urban'])
col3.metric("AI Model Accuracy", "99.50%")

# --- MAIN LAYOUT ---
map_col, chart_col = st.columns([2, 1])

with map_col:
    st.subheader(f"Geographic Sprawl Map: {year}")
    # Initialize Map
    m = folium.Map(location=[30.3753, 69.3451], zoom_start=6, tiles="CartoDB dark_matter")
    
    # Logic to add layers based on year
    if year >= 2022:
        # Add a placeholder circle for center of gravity
        folium.CircleMarker([31.5204, 74.3587], radius=20, color=stats[year]['color'], fill=True, tooltip="High Growth Zone").add_to(m)
    
    st_folium(m, width=800, height=500)

with chart_col:
    st.subheader("Growth Trends")
    chart_data = pd.DataFrame({
        'Year': [1998, 2017, 2022, 2030],
        'Population (M)': [130.7, 204.4, 230.1, 280.5]
    })
    fig = px.line(chart_data, x='Year', y='Population (M)', markers=True)
    fig.update_traces(line_color=stats[year]['color'])
    st.plotly_chart(fig, use_container_width=True)

# --- RISK RANKING TABLE ---
st.subheader("⚠️ District Risk Assessment")
# --- RISK RANKING TABLE ---
st.subheader("⚠️ District Risk Assessment")
risk_csv = os.path.join(os.path.dirname(__file__), "data", "predictions", "risk_ranking_2030.csv")

if os.path.exists(risk_csv):
    risk_data = pd.read_csv(risk_csv)
    st.dataframe(risk_data.style.background_gradient(subset=['sprawl_pixels'], cmap='Reds'))
else:
    st.warning("⚠️ Risk data not generated yet. Please run risk_dashboard.py first.")