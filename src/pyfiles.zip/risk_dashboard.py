import os
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sum as _sum, count as _count, round as _round
from pyspark.ml.clustering import KMeans
from pyspark.ml.feature import VectorAssembler

# 1. Pathing Fix
project_root = os.getcwd()
java11_dir = os.path.join(project_root, "java11_folder")
for item in os.listdir(java11_dir):
    if "jdk" in item.lower():
        os.environ['JAVA_HOME'] = os.path.join(java11_dir, item)
        break
os.environ['HADOOP_HOME'] = r'C:\hadoop'

# 2. Initialize Spark
spark = SparkSession.builder.appName("RiskDashboard").getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

print("\n" + "="*70)
print("  EXECUTIVE DASHBOARD: 2030 SPRAWL RISK RANKING")
print("="*70)

# 3. Load Sprawl Data
data_path = os.path.join(project_root, "data", "predictions", "sprawl_2030.parquet")
df = spark.read.parquet(data_path)

# 4. Re-Apply K-Means to Group Sprawl into the 15 Zones
assembler = VectorAssembler(inputCols=["lat", "lon"], outputCol="features")
df_features = assembler.transform(df)

kmeans = KMeans().setK(15).setSeed(42).setFeaturesCol("features")
model = kmeans.fit(df_features)
predictions = model.transform(df_features)

# Extract center coordinates to join later
centers = model.clusterCenters()
center_dict = {i: (round(centers[i][0], 4), round(centers[i][1], 4)) for i in range(15)}

# 5. Calculate Risk Metrics per Zone
# We group by the cluster ID, count the sprawl pixels (area size), and sum the population
risk_df = predictions.groupBy("prediction").agg(
    _count("*").alias("sprawl_pixels"),
    _sum("future_population").alias("impacted_population")
).toPandas()

# 6. Format the Final Table
risk_df["Epicenter_ID"] = risk_df["prediction"] + 1
risk_df["Latitude"] = risk_df["prediction"].apply(lambda x: center_dict[x][0])
risk_df["Longitude"] = risk_df["prediction"].apply(lambda x: center_dict[x][1])

# Sort by most dangerous zones (highest sprawl pixels)
risk_df = risk_df.sort_values(by="sprawl_pixels", ascending=False).reset_index(drop=True)

print(f"{'RANK':<5} | {'EPICENTER ID':<13} | {'LATITUDE':<10} | {'LONGITUDE':<10} | {'NEW SPRAWL AREA':<16} | {'IMPACTED POPULATION'}")
print("-" * 85)

for index, row in risk_df.iterrows():
    rank = index + 1
    epi_id = f"Center {int(row['Epicenter_ID'])}"
    lat = f"{row['Latitude']}"
    lon = f"{row['Longitude']}"
    area = f"{int(row['sprawl_pixels']):,} sq units"
    pop = f"{int(row['impacted_population']):,}"
    
    # Highlight top 3 highest risk
    if rank <= 3:
        print(f"{rank:<5} | {epi_id:<13} | {lat:<10} | {lon:<10} | {area:<16} | {pop}  <-- HIGH RISK")
    else:
        print(f"{rank:<5} | {epi_id:<13} | {lat:<10} | {lon:<10} | {area:<16} | {pop}")

print("-" * 85)
out_path = os.path.join(project_root, "data", "predictions", "risk_ranking_2030.csv")
risk_df.to_csv(out_path, index=False)
print(f"[+] Full Executive Report saved to: {os.path.basename(out_path)}")

spark.stop()