import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, log1p, udf
from pyspark.sql.types import FloatType
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.classification import RandomForestClassificationModel

# 1. Pathing Fix
project_root = os.getcwd()
java11_dir = os.path.join(project_root, "java11_folder")
for item in os.listdir(java11_dir):
    if "jdk" in item.lower():
        os.environ['JAVA_HOME'] = os.path.join(java11_dir, item)
        break
os.environ['HADOOP_HOME'] = r'C:\hadoop'

# 2. Initialize Spark
spark = SparkSession.builder.appName("PeriUrban").getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

print("\n" + "="*55)
print("  FEATURE 3: PERI-URBAN (SUBURB) CLASSIFICATION")
print("="*55)

# 3. Load Model and Base Data
data_path = os.path.join(project_root, "data", "processed", "ml_features.parquet")
model_path = os.path.join(project_root, "models", "rf_model")

print("[+] Loading AI Model...")
df = spark.read.parquet(data_path)
model = RandomForestClassificationModel.load(model_path)

# 4. Simulate 2030 (+50% High Growth)
df_future = df.withColumn("future_population", col("population") * 1.50)
df_future = df_future.withColumn("density_score", log1p(col("future_population")))

assembler = VectorAssembler(inputCols=["lat", "lon", "density_score"], outputCol="features")
df_future_ml = assembler.transform(df_future)

# 5. Predict
print("[+] Calculating Suburb Probabilities...")
predictions = model.transform(df_future_ml)

# 6. Extract Probability (The AI's confidence level)
# Probability is a vector: [prob_rural, prob_urban]. We want prob_urban (index 1).
get_urban_prob = udf(lambda v: float(v[1]), FloatType())
predictions = predictions.withColumn("urban_probability", get_urban_prob(col("probability")))

# 7. Filter for Peri-Urban (Transition Zones)
# We find areas currently rural, but with a 40% to 70% mathematical chance of becoming urban
peri_urban_df = predictions.filter(
    (col("is_urban") == 0) & 
    (col("urban_probability") >= 0.40) & 
    (col("urban_probability") <= 0.70)
)

count = peri_urban_df.count()
print(f"\n--- PERI-URBAN RESULTS ---")
print(f"Found {count:,} Peri-Urban (Suburban) transition grid cells.")

# 8. Save to Parquet
out_path = os.path.join(project_root, "data", "predictions", "peri_urban_2030.parquet")
peri_urban_df.select("lat", "lon", "future_population").write.mode("overwrite").parquet(out_path)

print(f"\n[+] Saved Peri-Urban zones to: {os.path.basename(out_path)}")
print("Task Completed Successfully!")

spark.stop()