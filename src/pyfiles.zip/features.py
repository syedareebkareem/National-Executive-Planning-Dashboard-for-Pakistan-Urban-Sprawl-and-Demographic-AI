import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, log1p, when, concat_ws, round

# 1. Java 11 & Hadoop Dynamic Pathing Fix
project_root = os.getcwd()
java11_dir = os.path.join(project_root, "java11_folder")
for item in os.listdir(java11_dir):
    if "jdk" in item.lower():
        os.environ['JAVA_HOME'] = os.path.join(java11_dir, item)
        break
os.environ['HADOOP_HOME'] = r'C:\hadoop'

# 2. Initialize Spark
spark = SparkSession.builder \
    .appName("FeatureEngineering") \
    .config("spark.driver.memory", "4g") \
    .getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

print("\n" + "="*35)
print("  TASK 4: FEATURE ENGINEERING")
print("="*35)

# 3. Load the cleaned Parquet data
input_path = os.path.join(project_root, "data", "processed", "cleaned.parquet")
print(f"[+] Loading cleaned data from: {os.path.basename(input_path)}")
df = spark.read.parquet(input_path)

# 4. Feature Engineering
print("[+] Generating Machine Learning Features...")

# Feature A: Grid ID (Grouping into 1km Macro-regions by rounding coordinates)
df_feat = df.withColumn("grid_id", concat_ws("_", round(col("lat"), 2), round(col("lon"), 2)))

# Feature B: Urbanization Label (1 = Urban, 0 = Rural)
df_feat = df_feat.withColumn("is_urban", when(col("population") > 50.0, 1).otherwise(0))

# Feature C: Density Score (Log transformation for ML stability)
df_feat = df_feat.withColumn("density_score", log1p(col("population")))

print("[+] Features Engineered successfully.")
df_feat.show(5)

# 5. Save ML-Ready Data
output_path = os.path.join(project_root, "data", "processed", "ml_features.parquet")
print(f"[+] Saving ML-ready Parquet file to: {output_path}")
df_feat.write.mode("overwrite").parquet(output_path)

# 6. Data Summary
total_count = df_feat.count()
urban_count = df_feat.filter(col("is_urban") == 1).count()
rural_count = total_count - urban_count

print("\n--- Sprawl Statistics ---")
print(f"Total Pixels: {total_count:,}")
print(f"Urban Pixels: {urban_count:,} ({(urban_count/total_count)*100:.2f}%)")
print(f"Rural Pixels: {rural_count:,} ({(rural_count/total_count)*100:.2f}%)")

print("\nTask 4 Completed Successfully!")
spark.stop()
