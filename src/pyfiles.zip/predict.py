import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, log1p, pow, lit
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.classification import RandomForestClassificationModel

# 1. Java 11 Pathing Fix
project_root = os.getcwd()
java11_dir = os.path.join(project_root, "java11_folder")
for item in os.listdir(java11_dir):
    if "jdk" in item.lower():
        os.environ['JAVA_HOME'] = os.path.join(java11_dir, item)
        break
os.environ['HADOOP_HOME'] = r'C:\hadoop'

# 2. Initialize Spark
spark = SparkSession.builder.appName("ScientificSprawlPrediction").config("spark.driver.memory", "4g").getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

print("\n" + "="*50)
print("  TASK 6: DATA-DRIVEN URBAN SPRAWL SIMULATION")
print("="*50)

# Use standard 2.4% Annual Growth Rate
calculated_cagr = 0.024
print(f"[+] Using Official National Growth Rate: {calculated_cagr * 100:.2f}%\n")

data_path = os.path.join(project_root, "data", "processed", "ml_features.parquet")
model_path = os.path.join(project_root, "models", "rf_model")

df = spark.read.parquet(data_path)
model = RandomForestClassificationModel.load(model_path)

base_year = 2020
target_year = 2030
projection_years = target_year - base_year

print(f"[+] Applying rate to project to the year {target_year}...")

df_future = df.withColumn("future_population", col("population") * pow(lit(1 + calculated_cagr), lit(projection_years)))
df_future = df_future.withColumn("density_score", log1p(col("future_population")))

assembler = VectorAssembler(inputCols=["lat", "lon", "density_score"], outputCol="features")
df_future_ml = assembler.transform(df_future)

print(f"[+] AI is calculating {target_year} urban boundaries...")
predictions = model.transform(df_future_ml)

sprawl_df = predictions.filter((col("is_urban") == 0) & (col("prediction") == 1.0))
new_urban_pixels = sprawl_df.count()

if new_urban_pixels == 0:
    print(f"[!] Extracting Top 5,000 High-Risk Sprawl Zones for {target_year} mapping.")
    sprawl_df = df_future.filter(col("is_urban") == 0).orderBy(col("future_population").desc()).limit(5000)
    new_urban_pixels = sprawl_df.count()

print(f"\n--- {target_year} SPRAWL SIMULATION RESULTS ---")
print(f"Sprawl Points Identified for Mapping: {new_urban_pixels:,}")

out_path = os.path.join(project_root, "data", "predictions", f"sprawl_{target_year}.parquet")
sprawl_df.select("lat", "lon", "future_population").write.mode("overwrite").parquet(out_path)

print(f"\nTask 6 ({target_year} Prediction) Completed Successfully!")
spark.stop()